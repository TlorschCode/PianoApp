#pragma once

void InitAudio();
