#include "globals.h"

std::string CURRENTNOTE = "None";
std::atomic<bool> RUNNINGPROGRAM = true;
std::atomic<bool> SHARPS = true;
