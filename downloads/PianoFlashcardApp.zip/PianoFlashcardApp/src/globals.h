#pragma once
#include <string>
#include <atomic>

extern std::string CURRENTNOTE;
extern std::atomic<bool> RUNNINGPROGRAM;
extern std::atomic<bool> SHARPS;